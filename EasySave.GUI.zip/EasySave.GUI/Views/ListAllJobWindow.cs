using Avalonia.Controls;

namespace EasySave.GUI.Views
{
    public partial class ListAllJobWindow : Window
    {
        public ListAllJobWindow()
        {
            InitializeComponent();
        }
    }
}
