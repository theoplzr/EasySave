using Avalonia.Controls;

namespace EasySave.GUI.Views
{
    public partial class JobFormWindow : Window
    {
        public JobFormWindow()
        {
            InitializeComponent();
        }
    }
}
